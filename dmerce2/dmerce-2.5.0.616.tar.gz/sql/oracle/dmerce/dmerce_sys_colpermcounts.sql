CREATE TABLE colpermcounts (
       uxsrole		   VARCHAR2(30),
       table_schema	   VARCHAR2(30),
       table_name	   VARCHAR2(30),
       column_name	   VARCHAR2(30),
       s		   NUMBER(1),
       i		   NUMBER(1),
       u		   NUMBER(1)
);
