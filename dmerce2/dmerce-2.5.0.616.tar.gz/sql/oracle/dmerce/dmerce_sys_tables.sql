CONNECT dmerce_sys/dmerce_sys;
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_configuration.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_samsessions.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_templates.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_sendemail.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_tabperms.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_colperms.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_colpermcounts.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_tabdefs.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_coldefs.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_uxsgroups.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_log.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_availprojects.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_manageprojects.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_projectnames.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_ippool.sql
@${DMERCE_SQLORACLE_HOME}/dmerce_sys_mclg.sql
