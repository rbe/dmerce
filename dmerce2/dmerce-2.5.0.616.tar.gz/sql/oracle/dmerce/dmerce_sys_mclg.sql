CREATE TABLE mclg (
       id                  NUMBER		NOT NULL,
       fqhn                VARCHAR2(200)	NOT NULL,
       stage               NUMBER               NOT NULL,
       ident               VARCHAR2(17)		NOT NULL,
       digits              NUMBER(2)		NOT NULL
);
