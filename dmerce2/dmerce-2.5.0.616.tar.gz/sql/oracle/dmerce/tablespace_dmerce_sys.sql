CREATE TABLESPACE dmerce_sys
       LOGGING
       DATAFILE '$datafiledir/dmerce_sys01.dbf'
       SIZE 10M;
