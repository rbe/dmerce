@tablespace_dmerce.sql
@tablespace_dmerce_sys.sql
