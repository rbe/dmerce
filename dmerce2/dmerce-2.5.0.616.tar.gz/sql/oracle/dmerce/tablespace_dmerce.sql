CREATE TABLESPACE dmerce
       LOGGING
       DATAFILE '$datafiledir/dmerce01.dbf'
       SIZE 20M;
