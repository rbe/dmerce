CONNECT dmerce_sys/dmerce_sys;
GRANT SELECT ON configuration TO dmerce_web;
GRANT SELECT ON samsessions TO dmerce_web;
GRANT INSERT ON samsessions TO dmerce_web;
GRANT UPDATE ON samsessions TO dmerce_web;
GRANT SELECT ON templates TO dmerce_web;
GRANT SELECT ON log TO dmerce_web;
