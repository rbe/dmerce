CREATE TABLE projectnames (
       id                  NUMBER		NOT NULL,
       projectname         VARCHAR2(8)
);
