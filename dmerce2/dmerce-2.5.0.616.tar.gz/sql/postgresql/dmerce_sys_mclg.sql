CREATE TABLE mclg (
	ID				numeric		NOT NULL,
	FQHN				varchar(200)	NOT NULL,
	Stage				numeric		NOT NULL,
	Ident				varchar(17)	NOT NULL,
	Digits				numeric(2)	NOT NULL
);
