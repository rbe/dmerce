CREATE TABLE availprojects (
	ID				numeric			NOT NULL,
	CreatedBy			numeric,
	CreatedDateTime			timestamp,
	ChangedBy			numeric,
	ChangedDateTime			timestamp,
	Name				varchar(255),
	Description			varchar(2000)
);
