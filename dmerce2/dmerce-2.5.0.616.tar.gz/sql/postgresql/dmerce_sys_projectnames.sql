CREATE TABLE projectnames (
	ID				numeric		NOT NULL,
	ProjectName			varchar(8)
);
