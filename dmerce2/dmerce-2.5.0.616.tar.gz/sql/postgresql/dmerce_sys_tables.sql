\i dmerce_sys_sequences.sql

\i dmerce_sys_configuration.sql
\i dmerce_sys_samsessions.sql
\i dmerce_sys_templates.sql
\i dmerce_sys_sendemail.sql
\i dmerce_sys_uxsgroups.sql
\i dmerce_sys_log.sql
\i dmerce_sys_availprojects.sql
\i dmerce_sys_manageprojects.sql
\i dmerce_sys_projectnames.sql
\i dmerce_sys_ippool.sql
\i dmerce_sys_mclg.sql
\i dmerce_sys_grants.sql
