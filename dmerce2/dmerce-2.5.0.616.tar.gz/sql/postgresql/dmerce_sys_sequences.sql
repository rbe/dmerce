CREATE SEQUENCE sendmail_id_seq;
